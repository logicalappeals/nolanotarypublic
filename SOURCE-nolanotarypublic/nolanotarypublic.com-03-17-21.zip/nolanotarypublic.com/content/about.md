+++
date = "1988-10-23"
title = "About"
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-8"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100888059-8');
</script>


# <center>**NOLA Notary Public**</center>
## <center>**A New Orleans, Louisiana Notary, Title, and Document Drafting Service**</center> 

![NOLA Notary](/img/nola-notary.jpg "NOLA Notary")

> ### NOLA Notary Public ⚜️ offers low cost, affordable, notary services in **New Orleans**. 📃 🖋️ ☑️

## 🧾💲 Notary Service Prices: 

## $20 per notarization 💵 💳  
### (i.e. our notary will notarize & stamp/seal your document for $20).  

-------------------------------
Walk-ins Welcome.

_NOTE: Please call ahead to ensure that the notary is not out of the office_

📞 office line: **(504) 766 - 6111**

### Call or Text NOLA Notary Public and Notarize your Document Today 

> NOLA Notary Public is located in Mid-City New Orleans :

------------------------------

🏡 **Uptown Office**: 8200 Hampson St., Ste. 229 - New Orleans, LA 70119

------------------------------

>_NOLA NOTARY PUBLIC is open weekdays 8:30 - 5:00_  


## NOLA NOTARY PUBLIC Also Offers the following Affordable, Low Cost Services:

## Acknowledgement 📝 - $20

 Do you need a document that certifies you executed another document as your free act and deed?  We've got you covered with a Louisiana certificate of acknowledgment. 

## Affidavit 📄🖊️ - $40
Need an affidavit in New Orleans or Jefferson Parish? We will prepare and notarize a simple affidavit for you at our office. Examples include:

   - General Affidavits
   - Affidavits of No Employees
   - Custom Affidavits

## Louisiana Will (Notarial Testament)📃🖋️ - $100
Do you need a will in New Orleans?  We will draft a simple will for you that complies with substance and form requirements of Louisiana Law. 

## Quit Claim Deed (Orleans Parish) 📜🏠 - $400
In need of a Quit Claim Deed? We've got you covered. We will draft a quit claim deed for you and file it Orleans Parish.  

## Succession (Orleans Parish) ⚰️💰 - $400
Death is an inevitable part of life . . . NOLA Notary Public will prepare and file a small succession in Orleans Parish.  Sorry for your loss 😢 
## Power of Attorney ⚖️ - $75
We will draft a power of attorney for you so that others can act on your behalf.
## Medical Power of Attorney ⚕️ - $50
We will draft a durable Medical power of attorney for you so that someone else can make medical decisions for you should the need arise.
## Bill of Sale 🧾 - $25
Sometimes you need to sell something like a car or truck or a tractor.  We will prepare a bill of sale to help facilitate your transaction.  
## Court Filing Services 📥 - $50
Do you want to file your document in the public records and make it "good against the world." We will file a document in Orleans or Jefferson Parish Court for you.
## Mobile Notary Service 🚗 - $50
We will travel to you, within Orleans or Jefferson Parishes, to notarize your document.  Call (504) 822 - 2255 to book your appointment today.

-----------------------------

If you are in the **Metro New Orleans** area, particularly _Lakeview, Mid-City, Uptown, Gentilly, Downtown, CBD, or Bayou St. John_ and need a quick, cheap, and affordable way to notarize your documents, contact NOLA Notary Public at **(504) 766 - 6111** and schedule an appointment today.
