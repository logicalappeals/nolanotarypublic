--- 
author: "NOLA Notary Public" 
date: 2019-03-30 
title: How to Become a Louisiana Notary?
best: false 
tags: ["notary","public","new orleans"] 
--- 

<!-- Global site tag (gtag.js) - Google Analytics --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-8"></script> 
<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-8'); 

</script> 

# <center> How to become a Louisiana Notary?</center>  

![New Orleans Notary](/img/notary-new-orleans.jpg "Notary in New Orleans")  

Louisiana law, particularly [RS 35:191](http://www.legis.la.gov/Legis/Law.aspx?d=92603) A.(1), states that any person may be appointed as a notary public in and for the parish in which he resides and in and for any one other parish in which he maintains an office.  Here, the main requirement is residency.   

__Note__: the plain language of [RS 35:191](http://www.legis.la.gov/Legis/Law.aspx?d=92603) requires that a person seeking to be appointed as a notary public in a parish must be a resident of that parish or maintain an office in the parish.  Nevertheless, Louisiana law provides that an applicant must apply to become a notary in his parish of residence before applying to become a notary in another parish.  

## Louisiana Notary Public Requirements 

Additionally, to become a Notary Public in Louisiana, the law requires that an applicant: 

(a) Is a resident citizen or alien of this state. 

(b) Is eighteen years of age or older. 

(c ) Reads, writes, speaks, and is sufficiently knowledgeable of the English language. 

(d) Has received a high school diploma, has received a diploma for completion of a home study program approved by the State Board of Elementary and Secondary Education, or has been issued a high school equivalency diploma after successfully completing the test of General Educational Development. 

(e) Is not under interdiction or incapable of serving as a notary because of mental infirmity. 

(f) Has not been convicted of a felony, or if convicted of a felony, has been pardoned. 

(g) Meets the requirements established by law for each commission sought. 

### How do I become a Louisiana Notary?

Additionally, the applicant must be of good moral character, integrity, competency and sober habits. The applicant must also pass a written examination administered by the office of the Secretary of State.  However, the aforesaid written examination is not required if the applicant has been duly admitted to practice law in the State of Louisiana or if he holds a valid notarial commission in Louisiana. 

For more requirements, see the full text of [RS 35:191](https://www.legis.la.gov/Legis/Law.aspx?d=92603)  

--------------------------  

[NOLA Notary Public](https://nolanotarypublic.com) is a Notary, Title Transfer, and Document Drafting Service based in New Orleans, LA. 🖋️🧾️ 👨‍💻 

You can learn more about NOLA Notary Public ⚜️by clicking [here](https://nolanotarypublic.com/about/).   

> Call and Schedule a Notary Appointment Today: 

📞 Office: (504) 822 - 2255
  
[See More Content](https://nolanotarypublic.com/blog/) 💻  

  

  

 

 