+++
date = "1988-10-23"
title = "About"
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-8"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100888059-8');
</script>


# <center>**NOLA Notary Public**</center>
## <center>**A New Orleans, Louisiana Notary, Title, and Document Drafting Service**</center> 

![NOLA Notary](/img/nola-notary.jpg "NOLA Notary")

> ### NOLA Notary Public ⚜️ offers low cost, affordable, notary services in **New Orleans**. 📃 🖋️

#### NOLA NOTARY PUBLIC notarizes documents by appointment only

Notary Pricing:

   - **$10** per document for the **first (3) documents**; and  
   - **$5** per document for each document thereafter
 
## Call NOLA NOTARY PUBLIC Co. and Schedule an appointment today ✉️📠

🏢 Office: 932 Hidalgo Street, Ste. C, New Orleans, LA 70124

📞 phone: (504) 400 - 9926

-----------------------------

#### NOLA NOTARY PUBLIC Offers Cheap, Affordable, Low Cost Notary Services in New Orleans as well as:
   - custom document drafting;
   - wills;
   - bills of sale; 
   - title transfer services; 
   - court filing services;

If you are in Lakeview, Mid-City, Gentilly, or Bayou St. John and need a quick, cheap, and affordable way to notarize your documents, contact NOLA Notary Public and schedule an appointment today.
