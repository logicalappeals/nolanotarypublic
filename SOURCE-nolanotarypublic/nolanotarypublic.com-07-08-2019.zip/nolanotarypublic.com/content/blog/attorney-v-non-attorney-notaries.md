--- 
author: "NOLA Notary Public" 
date: 2019-06-21 
title: Attorney v Non Attorney Notaries
best: false 
tags: ["notary","public","new orleans"] 
--- 

<!-- Global site tag (gtag.js) - Google Analytics --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-8"></script> 
<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-8'); 

</script> 

# Attorney vs. Non-Attorney Notaries: What's the Difference?

![New Orleans Notary](/img/attorney-vs-non-attorney-notary.jpg "Louisina Notary Jurisdiction") 

Generally speaking, the difference between what a non-attorney notary and a notary with an active law license ultimately boils down to the minutiae of when, where, and how each is allowed to exercise their authority. 

### Are All Notaries Required to Have a Law License? 

Due to the significant role a notary has in the legal process, many assume that being a licensed attorney is mandatory to qualify for the accreditation necessary to perform notarial functions and exercise this authority. In actuality, it is possible for non-attorneys to become appointed notaries, and unlike other states, Louisiana notaries in good standing—meaning their license has not been revoked or subject to suspension—are considered “commissioned for life.”

### Am I in Good Hands If I See a Notary Who Does Not Have a Law License?

Technically speaking, yes you are. However, you may prefer to see [licensed Lousiana attorney](https://ambrosialaw.com) over the alternative, depending on the complexity of your needs. 

Although Louisiana statutes appear more flexible than other states in terms of enabling notary appointment, there are certain standards and expectations one is still expected to meet in order to effectively execute the comprehensive range of sanctioned tasks a notary is authorized to carry out. Proficient comprehension of the law, particularly as it pertains to notarial powers and responsibilities, is critical to successfully fulfilling these duties.

Currently, those who seek notary commission who aren’t licensed to practice law in Louisiana are obligated to verify the breadth of their knowledge via the aforementioned written exam. So while those who lack a law license might be considered capable of righteously upholding a notary position, keep in mind that should you come across a non-attorney notary commissioned on or before [June 13, 2005](https://nolanotarypublic.com/what-is-a-notarys-jurisdiction/), it’s likely their legal and notarial proficiency was never measured against the basic criteria needed to perform well.

Conversely, [attorneys who are licensed and in good standing in Louisiana](https://ambrosialaw.com/about/) can become a commissioned notary without taking the Louisiana State Notary exam, as long as they meet the rest of the requirements noted in [La. Rev. Stat. Ann. § 35:191.1.](http://www.legis.la.gov/Legis/Law.aspx?d=92603) Licensed attorneys are exempt from the exam is because their active esquire status signifies their mastery of Louisiana law, including how to apply relevant legal concepts to the drafting, preparing, and administration of affidavits, acknowledgements, and authentic Acts as a civil law notary. Furthermore, attorney notaries have statewide jurisdiction, as dictated by [La Rev. Stat. Ann. § 35:191.1(P)](http://www.legis.la.gov/Legis/Law.aspx?d=92603).	

--------------------------

[NOLA Notary Public](https://nolanotarypublic.com) is a Notary, Title Transfer, and Document Drafting Service based in New Orleans, LA. 🖋️🧾️ 👨‍💻 

You can learn more about NOLA Notary Public ⚜️by clicking [here](https://nolanotarypublic.com/about/).   

> Call and Schedule a Notary Appointment Today: (504)400-9926 📲
  
[See More Content](https://nolanotarypublic.com/blog/) 💻  
