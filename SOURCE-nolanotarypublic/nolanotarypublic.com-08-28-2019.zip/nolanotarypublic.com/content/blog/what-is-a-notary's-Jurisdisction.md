--- 
author: "NOLA Notary Public" 
date: 2019-06-20 
title: What is A Notary's Jurisdiction?
best: false 
tags: ["notary","public","new orleans"] 
--- 

<!-- Global site tag (gtag.js) - Google Analytics --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-8"></script> 
<script> 

  window.dataLayer = window.dataLayer || []; 

  function gtag(){dataLayer.push(arguments);} 

  gtag('js', new Date()); 

  

  gtag('config', 'UA-100888059-8'); 

</script> 




# <center> What Determines a Notary’s Jurisdiction of Power?</center>

![New Orleans Notary](/img/louisiana-notary-jurisdiction.jpg "Louisina Notary Jurisdiction") 

After [becoming an appointed notary](https://nolanotarypublic.com/how-to-become-a-louisiana-notary/) in Louisiana, all notaries have the authority to make oaths; give oaths; swear someone in prior to their given testimony during a deposition while reporters are present; as well as confirm and authenticate information, such as interrogatories or other pleadings, in courts of record for Louisiana, as described in [La. Rev. Stat. Ann. § 35:3](http://legis.la.gov/Legis/Law.aspx?d=92624) and [La. Rev. Stat. Ann. § 35:2(B)](http://legis.la.gov/Legis/Law.aspx?d=92612). 

Whether one is licensed to practice law in Louisiana or not, an appointed notary public’s ability to wield their powers is contingent upon a few key factors:

### (1) When They Were Appointed as Notaries

This condition generally has the greatest impact on non-attorney notaries. Anyone who is not licensed to practice law or who did not obtain a valid notarial commission prior to June 13, 2005 must pass the written exam administered by the secretary of state. For the most part, a non-attorney notaries commissioned on or before June 13, 2005 without having taken or passed the Louisiana State Notary exam described in [La. Rev. Stat. Ann. § 35:191.1](http://www.legis.la.gov/Legis/Law.aspx?d=92603) may continue to exercise all notarial powers in the parish they were previously authorized to receive commission, as well as in its designated reciprocal parishes. They may also maintain dual commissions obtained prior to the previously mentioned date, and continue to exercise their notarial authority without taking the written test.

### (2) What Parish or Parishes They Were Commissioned In

Referred to as “reciprocal parishes,” Louisiana parishes are organized into designated categories that ultimately define the parameters for the jurisdiction they are legally allowed to perform notarial duties, exercise this authority, and earn commission. This means that if someone is an appointed notary in a particular parish, they are also allowed to act as a notary in its reciprocal parishes. For instance, a notary who is commissioned in Orleans can also act as a notary in Jefferson, St. Bernard, and Plaquemines. Some parishes, such as Livingston, appear in more than one group. Should a notary earn their commissioning powers from a parish that’s categorized in multiple groups, they can exercise their notarial powers across the affiliated reciprocal parishes.

[Click here for more information about reciprocal parish groups](http://www.legis.la.gov/Legis/Law.aspx?d=92603).


### (3) Where They’ve Established Residency

If one becomes a certified notary in the same parish as their primary residence, they are allowed to perform all notarial functions not only in their parish of residence, but also in any adjacent parish with a population of less than 40,000 people without completing an additional application or paying more fees. This also applies to the parish in which their office of employment is located. 

[Attorneys with notarial power have statewide jurisdiction](https://www.sos.la.gov/NotaryAndCertifications/FileNotaryDocuments/FrequentlyAskedQuestions/Pages/default.aspx?OwnershipName=FileNotaryDocuments&faqid=0). This means if a person is licensed to practice law in the state of Louisiana, and they fulfill all other requirements outlined in [La. Rev. Stat. Ann. § 35:191](http://www.legis.la.gov/Legis/Law.aspx?d=92603) (with the exception of the notary exam), they are allowed to exercise their notarial authority in all parishes. However, they are only able to receive commission in their designated parish of residence. Should they relocate from their original parish of commission, they are required to transfer their commission, unless where they move is a reciprocal parish of their initial parish of commission.

--------------------------

[NOLA Notary Public](https://nolanotarypublic.com) is a Notary, Title Transfer, and Document Drafting Service based in New Orleans, LA. 🖋️🧾️ 👨‍💻 

You can learn more about NOLA Notary Public ⚜️by clicking [here](https://nolanotarypublic.com/about/).   

> Call and Schedule a Notary Appointment Today: 

📞 Office: (504) 822 - 2255

📲 Cell/Text: (504) 400-9926 
  
[See More Content](https://nolanotarypublic.com/blog/) 💻  
