 --- 
author: "NOLA Notary Public" 
date: 2019-03-10 
title: What is a Notary?
best: false 
tags: ["notary","public","new orleans"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100888059-8"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100888059-8');
</script>

# <center>What is a Notary?</center> 

![New Orleans Notary](/img/new-orleans-civil-law-notary.jpg "New Orleans Notary") 

## <center> Notary Public Definition</center> 

Louisiana law does not directly define the term “notary public.”  Nevertheless, the Louisiana State Legislature is tasked with creating and controlling the office of notary public in Louisiana.   

So . . . What is a notary? 

Merriam-Webster's dictionary defines a notary as: “a public officer who attests or certifies writings (such as a deed) to make them authentic and takes affidavits, depositions, and protests of negotiable paper.” Merriam–Webster Online Dictionary, 2019 Merriam–Webster, Incorporated, available at https://www.merriam-webster.com/dictionary/notary%20public 

## Louisiana Civil Law Notary 

Louisiana’s civil law notaries provide a variety of different services to the public.  Regarding the functions of a Louisiana Civil Law Notary, the New Orleans Notarial Archives states that: 

“The notary at civil law is a highly trained public official who drafts private agreements into documentary language and then functions as an archivist of the document he or she creates. The properly signed contract executed before a notary public at civil law is an “authentic act,” deemed to be proof of its contents. … The civil law notarial system is designed to provide a clear and reliable framework for citizens to conduct their legal business at least cost.” [New Orleans Notarial Archives](https://web.archive.org/web/20040219025110/http://www.notarialarchives.org/civil.htm), 2004


Accordingly, Louisiana notaries are civil law notaries who are granted broad powers under the law to perform certain legal acts, such as drafting and authenticating documents.  Moreover, Louisiana notaries have various duties and obligations unique to Louisiana law – _note:_ other states generally do not impose such broad powers and obligations on notaries.   

## Louisiana Notary Appointment 

In Louisiana, the Governor appoints notaries after they meet the qualifications required of the office of Notary Public. [LA RS 35:1](http://www.legis.la.gov/Legis/Law.aspx?d=92591) 

The Governor of Louisiana appoints a notary as a notary public in and for a particular parish.  The parish where the notary is appointed is determined by where the notary is domiciled and register to vote.  [LA RS 35:191](http://www.legis.la.gov/Legis/Law.aspx?d=92603)   

As a general rule, the notary should refer to the parish of his appointment in all of the acts he executes: 

“**Before me**, the undersigned notary public, duly commissioned and qualified in and for the parish of ___________, state of Louisiana” 

If a Louisiana notary executes an act in a parish other than the parish in which he was appointed, then he should state the parish of his commission as well as the parish where the act is executed: 

“**Before me**, the undersigned notary public, duly commissioned in and for the parish of __________, qualified to act in and for the parish of __________, state of Louisiana” 

OR 

“**Before me**, the undersigned notary public, duly commissioned in and for the Parish of ___________ and qualified to act in any parish of Louisiana” 

## Louisiana Attorney as a Notary Public 

Many Louisiana attorneys are also notaries.  Attorneys licensed to practice law in Louisiana are qualified to receive a commission as a notary public without having to take the Louisiana State Notary exam.   

For more information regarding Louisiana Notary appointment, qualifications, and bonds, see [LA RS 35:191](http://www.legis.la.gov/Legis/Law.aspx?d=92603) 

-------------------------- 

[NOLA Notary Public](https://nolanotarypublic.com) is a Notary, Title Transfer, and Document Drafting Service based in New Orleans, LA. 🖋️🧾️ 👨‍💻    

You can learn more about NOLA Notary Public ⚜️ by clicking [here](https://nolanotarypublic.com/about/).  

> Call and Schedule a Notary Appointment 
Today: 

📞 Office: (504) 822 - 2255

📲 Cell/Text: (504) 400-9926 

[See More Content](https://nolanotarypublic.com/blog/) 💻 

 

 